"""
llmsherpa.

APIs to accelerate LLM use cases.
"""

__version__ = "0.1.3"
__author__ = 'Ambika Sukla'
__credits__ = 'NLMATICS CORP.'